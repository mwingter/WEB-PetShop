Pet Shop Functional Mockup

Grupo:
Luís Filipe Vasconcelos Peres NUSP: 10310641
Marcelo Duchene NUSP: 8596351
Michelle Wingter da Silva NUSP: 10783243

# Descrição de cada arquivo submetido:

#FILE                            #Description
-
-calendar.html                  calendario para agendamentos de servicos
-cart.html                      carrinho de compras
-index.html                     pagina principal
-login.html                     pagina para login
-meu-pet.html                   pagina do animal do usuario
-produtos.html                  pagina com os produtos da loja
-register.html                  pagina para registrar usuarios
-schedule.html                  pagina de cronograma da semana
-servicos.html                  pagina dos servicos prestados pela loja
-images/                        pasta das imagens do site
-style.css                      arquivo com os estilos do site

